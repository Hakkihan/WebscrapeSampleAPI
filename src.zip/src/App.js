import logo from './logo.svg';
import './App.css';
import Homepage from './components/Homepage';
// import Searchbar from './Searchbar';

function App() {
  return (
    <div>
      <Homepage />
    </div>
  );
}

export default App;
